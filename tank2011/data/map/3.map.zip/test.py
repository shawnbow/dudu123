import json
f = open("map.cfg","r")

txt = "".join(f.readlines())
f.close()
print json.loads(txt)
